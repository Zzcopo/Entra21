import java.awt.im.InputContext;
import java.util.Scanner;

public class Altura {
      public static void main(String[] args) {
		
    
    Scanner input = new Scanner(System.in);
        
    System.out.println("insira sua altura: ");
    double altura = input.nextDouble();
    
    System.out.println("a sua altura � :" + altura);
    	  
    	  
    	  
    	  
	}
}
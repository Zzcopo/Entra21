import java.util.Scanner;

public class atividade2 {
	public static void main(String[] args) {
		
	Scanner input = new Scanner(System.in);
	
	double NotaA = 3.5;
	//System.out.println("Qual a primeira nota? ");
	double NotaB = 6.5;
//	System.out.println("Qual a segunda nota? ");
	double Media = NotaA + NotaB / 2;
	
	System.out.println("A m�dia entre 3.5 e 6.5 �: " + Media);

	
	}	
}
